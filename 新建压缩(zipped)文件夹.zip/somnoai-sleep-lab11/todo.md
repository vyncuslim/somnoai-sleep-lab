# SomnoAI Digital Sleep Lab - 开发任务清单

## 核心功能模块

### 用户认证系统
- [x] 邮箱/密码注册界面
- [x] 邮箱/密码登录界面
- [x] Google OAuth 集成（自定义页面，使用 GOOGLE_CLIENT_ID/SECRET）
- [x] 会话管理与登出功能
- [x] 用户信息管理
- [x] 自定义登录页面（不使用默认 Manus 登录）

### Dashboard 首页
- [x] 圆环进度条显示睡眠评分
- [x] 网格卡片展示关键指标（总时长、深睡比、REM 比、睡眠效率）
- [x] 睡眠阶段折线图（深睡、浅睡、REM、清醒）
- [x] 心率监测卡片（平均、最低、最高 BPM）
- [x] 本周趋势柱状图
- [x] AI 睡眠洞察列表
- [x] Google Fit 同步卡片
- [x] 步速和卡路里数据

### 手动数据录入
- [x] 手动录入页面（睡眠时间、质量评分、心率）
- [x] 数据验证和保存
- [ ] 批量导入 CSV 功能
- [ ] 编辑和删除已录入数据

### Google Fit 集成
- [x] Google OAuth 认证流程
- [x] 获取睡眠段数据（服务已创建）
- [x] 获取心率数据（服务已创建）
- [x] 同步状态提示（UI 组件已创建）
- [ ] 定时自动同步（后台任务）
- [ ] 错误处理与重试机制

### 趋势分析页面
- [x] 周维度分析视图（7 天数据）
- [x] 月维度分析视图（30 天数据）
- [x] 年维度分析视图（12 个月数据）
- [x] 睡眠评分波动曲线
- [x] 睡眠时长波动曲线
- [x] 深睡比例波动曲线
- [ ] 对比分析工具

### 睡眠日历
- [x] 日历页面创建
- [x] 历史记录查询
- [x] 日期详情页面
- [ ] 数据回溯分析

### 闹钟与通知
- [ ] 闹钟设置界面
- [ ] 智能唤醒功能
- [x] 通知中心
- [ ] 系统偏好设置

### 导航系统
- [x] 首页导航
- [x] 日历导航
- [x] AI 助手导航
- [ ] 闹钟导航
- [ ] 我的（用户中心）导航

## UI/UX 设计
- [x] 深蓝/靛蓝渐变背景
- [x] 毛玻璃效果（Glassmorphism）
- [x] 青色与金色高光
- [x] 流畅入场动画
- [ ] 微交互效果
- [x] 华文界面本地化

## 测试与部署
- [ ] 单元测试编写（API 路由）
- [ ] 集成测试（Google Fit 同步）
- [ ] UI 测试
- [ ] 性能优化
- [x] 部署配置（Manus 托管）

### 自定义通知系统
- [x] 通知数据库模型
- [x] 通知创建与管理 API
- [x] 通知中心页面
- [x] 通知徽章组件
- [x] 通知钩子（useNotifications）
- [ ] 实时通知推送
- [ ] 通知类型配置（睡眠提醒、心率异常、目标达成等）

### 真实法律文件
- [x] 完整的隐私政策（包含数据收集、使用、保护等详细内容）
- [x] 完整的服务条款（包含使用条件、责任限制、用户义务等）

### AI 聊天助手增强
- [x] AI 助手页面创建
- [ ] Gemini API Key 输入界面
- [ ] API Key 安全存储
- [ ] 聊天界面完善
- [ ] 基于睡眠数据的个性化建议
- [ ] 消息历史记录管理


## 新增功能 - AI 聊天助手与 Google Fit 集成

### AI 聊天助手增强
- [ ] 添加 Gemini API Key 输入界面到 AI 助手页面
- [ ] API Key 安全存储在用户偏好设置
- [ ] 实现多轮对话聊天界面
- [ ] 基于睡眠数据的个性化建议生成
- [ ] 聊天历史记录保存和显示

### Google Fit 真实数据集成
- [ ] Dashboard 中添加"连接 Google Fit"按钮
- [ ] 实现 Google Fit OAuth 授权流程
- [ ] 获取用户最近 7 天的睡眠数据
- [ ] 获取用户最近 7 天的心率数据
- [ ] 获取用户最近 7 天的步数和卡路里数据
- [ ] 将真实数据展示在 Dashboard 上
- [ ] 添加同步状态指示器和手动刷新按钮

### Gemini API 集成
- [ ] 创建后端 API 路由处理 Gemini 请求
- [ ] 基于睡眠数据生成个性化改善建议
- [ ] 实现流式响应处理
- [ ] 错误处理和重试机制


## 新增功能 - Google Fit 同步状态反馈系统

### 数据库扩展
- [x] 添加 googleFitSyncStatus 表用于追踪同步状态
- [x] 记录同步开始时间、结束时间、状态、错误信息

### 后端 API 增强
- [x] 创建 getStatus 端点获取当前同步状态
- [x] 创建 getSyncHistory 端点获取同步历史
- [ ] 实现同步进度追踪和错误日志记录
- [ ] 添加同步超时处理和重试機制

### 前端 UI 改进
- [x] 创建 GoogleFitSyncEnhanced 组件显示详细的同步状态
- [x] 添加同步进度条和百分比显示
- [x] 实现同步状态轮询（每 2 秒更新一次）
- [x] 添加"正在同步"、"同步成功"、"同步失败"的视覺反馈
- [x] 显示最后同步时间和同步耗时

### 错误处理与提示
- [x] 显示具体的错误信息（如网络错误、权限不足等）
- [x] 添加同步历史记录显示
- [ ] 提供重试按黮u和故障排查建议

### 隐私政策更新
- [x] 更新隐私政策以包含 Google Fit 数据处理的详细信息
- [x] 添加数据授权、使用限制、安全与断开连接的章节

### 测试
- [x] 编写单元测试验证同步状态逻辑
- [x] 测试不同的同步场景（成功、失败、超时等）


## Bug 修复 - Google SDK 加载问题

### 问题诊断
- [x] 调查 Google SDK 加载失败的具体原因（网络、CDN、CORS 等）
- [x] 检查浏览器控制台的详细错误信息
- [x] 验证 Google Cloud Console 中的凭据配置

### 解决方案
- [x] 实现更健壮的 Google SDK 加载机制（重试、超时、fallback）
- [x] 添加加载超时处理（如 5 秒后仍未加载则显示错误）
- [x] 实现 fallback 方案（如果 Google SDK 加载失败，禁用 Google Sign-In 按黮u）
- [x] 改进错误提示，告知用户具体的加载失败原因
- [x] 添加手动重试按黮u

### 测试
- [x] 测试 Google SDK 加载成功的情况
- [x] 测试 Google SDK 加载失败的情况
- [x] 测试网络中断后的恢复
- [x] 测试多次重试的行为


## 新增功能 - Google Fit 标准流程集成

### 前端 Google 登录优化
- [x] 使用 Google Identity Services 库获取 authorization_code
- [x] 改进前端 Google 登录组件（使用官方 Google Sign-In 组件）
- [x] 处理 authorization_code 并发送到后端
- [x] 后端交换 authorization_code 获取 access_token 和 refresh_token

### 授权确认流程
- [ ] 创建权限确认页面，让用户勾选要授予的权限
- [ ] 显示 Google Fit 数据访问权限列表（步数、活动、睡眠、心率等）
- [ ] 用户确认后，后端使用 access_token 调用 Google Fit API

### Google Fit API 调用
- [x] 实现获取步数数据（Step Count）
- [x] 实现获取活动类型数据（Activity Segments）
- [x] 实现获取睡眠阶段数据（Sleep Stages）
- [x] 实现获取心率数据（Heart Rate）
- [x] 处理 API 响应并存储到本地数据库

### 数据治理
- [x] 不在数据库中缓存 access_token 和 refresh_token
- [x] 使用环境变量或安全存储保存 token
- [x] 实现用户数据删除機制（删除所有同步的 Google Fit 数据）
- [x] 实现 token 刷新機制（当 token 过期时自动刷新）
- [ ] 添加数据加密存储（敏感数据）

### 隐私和安全
- [x] 更新隐私政策，说明 token 不被缓存
- [ ] 添加数据删除选项到用户设置
- [x] 实现审计日志（记录数据访问和删除操作）
- [ ] 添加 token 过期时间显示和手动刷新选项

### 测试
- [x] 编写单元测试验证 Google Fit API 数据解析
- [x] 测试所有数据类型（步数、活动、睡眠、心率）
- [x] 测试数据解析的边界情况
- [ ] 测试 token 刷新機制
- [ ] 测试数据删除機制
- [ ] 测试错误处理（API 失败、权限不足等）


## 新增功能 - Token 过期时间显示和手动刷新

### 后端 API
- [x] 创建 /api/trpc/googleFit.getTokenStatus 端点获取 Token 过期时间
- [x] 创建 /api/trpc/googleFit.refreshToken 端点手动刷新 Token
- [x] 返回 Token 过期时间、距离过期的时间、刷新状态等信息

### 前端组件
- [x] 创建 GoogleFitTokenStatus 组件显示 Token 状态
- [x] 显示 Token 过期时间（格式化为可读时间）
- [x] 显示距离过期的剩余时间（如"2 天后过期"）
- [x] 显示 Token 状态指示器（绿色=有效、黄色=即将过期、红色=已过期）
- [x] 添加手动刷新按黮u，点击后刷新 Token
- [x] 显示刷新状态（正在刷新、刷新成功、刷新失败）

### 仪表板集成
- [x] 在仪表板的 Google Fit 部分添加 Token 状态显示
- [ ] 在用户设置中添加 Google Fit 连接状态和 Token 管理
- [ ] 添加"撤销 Google Fit 访问权限"按黮u

### 测试
- [x] 编写单元测试验证 Token 状态获取
- [x] 编写单元测试验证 Token 刷新逻辑
- [x] 测试 Token 过期时间计算
- [x] 测试错误处理（刷新失败、网络错误等）

## Bug 修复 - CDN 加载问题
- [ ] 诊断 https://files.manuscdn.com/manus-space-dispatcher/spaceEditor-uWiuPT8S.js 加载失败
- [ ] 检查网络连接和 CDN 可用性
- [ ] 实现 CDN 加载失败的降级方案


## 新增功能 - 默认访客模式
- [x] 修改 App.tsx 使其默认进入访客模式
- [x] 用户无需登录即可使用应用
- [x] 用户仍可在 Home 中选择退出访客模式


## Bug 修复 - Google 登录 SDK 未加载

### 问题描述
- [x] Google 登录 SDK 未能正确加载
- [x] 网络请求失败（Facebook、Google Ads 等第三方脚本）
- [x] 用户无法使用 Google 登录功能

### 根本原因分析
- [x] 检查 Google SDK 脚本加载的 CORS 配置
- [x] 验证 Google Cloud Console 中的凭据配置
- [x] 检查网络连接和 CDN 可用性
- [x] 分析 Content Security Policy (CSP) 是否阻止脚本加载

### 解决方案
- [x] 改进 Google SDK 加载机制，添加重试逻辑
- [x] 实现更好的错误提示和恢复機制
- [x] 添加 fallback 方案（如果 Google SDK 加载失败，提供邮箱登录选项）
- [x] 优化脚本加载顺序和超时时间

### 测试
- [x] 测试 Google SDK 加载成功的情况
- [x] 测试 Google SDK 加载失败的情况
- [x] 测试网络中断后的恢复
- [x] 测试 fallback 登录方案


## Bug 修复 - 访客模式流程问题
- [ ] 用户点击"开始使用"后自动返回欢迎页面
- [ ] 访客模式状态未正确保存到 localStorage
- [ ] Landing 页面的"开始使用"按钮逻辑错误
